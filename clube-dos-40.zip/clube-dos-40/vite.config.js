import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base: "./" faz os arquivos serem referenciados de forma relativa,
// o que é necessário pro GitHub Pages funcionar (ele serve o site
// dentro de um subcaminho, tipo seuusuario.github.io/clube-dos-40/)
export default defineConfig({
  plugins: [react()],
  base: "./",
});
