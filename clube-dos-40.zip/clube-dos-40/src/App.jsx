import React, { useState, useEffect, useMemo } from "react";
import { Plus, X, Trash2, Trophy, Users, Calendar, ArrowLeft, ChevronRight, Award, Search } from "lucide-react";

// ---------------------------------------------------------------------------
// Tokens — campo à noite, giz branco, ouro de taça, e um toque de coral pra
// dar festa. Time: verde escuro de gramado + dourado de campeão + coral vivo.
// ---------------------------------------------------------------------------
const C = {
  bg: "#0E3B2C",
  bg2: "#123A2C",
  card: "#16493A",
  cardAlt: "#1B5643",
  line: "#3D7A5D",
  chalk: "#FBF8EE",
  chalkDim: "#B9D4C5",
  gold: "#F0BD4A",
  goldSoft: "#F0BD4A33",
  coral: "#FF6B4A",
  red: "#D64545",
  yellow: "#F0C230",
  teamA: "#4FBE8C",
  teamB: "#F0BD4A",
};

const DISPLAY_FONT = "'Arial Rounded MT Bold', 'Segoe UI Rounded', 'Helvetica Rounded', Arial, sans-serif";
const CONDENSED_FONT = "'Arial Narrow', 'Helvetica Neue', Arial, sans-serif";
const MONO_FONT = "ui-monospace, SFMono-Regular, Menlo, Consolas, monospace";

const uid = () => Math.random().toString(36).slice(2, 10);

function formatDate(iso) {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

function initials(name) {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() || "")
    .join("");
}

const EVENT_META = {
  goal: { label: "Gol", icon: "⚽", color: C.chalk },
  assist: { label: "Assistência", icon: "🅰️", color: C.chalk },
  yellow: { label: "Cartão amarelo", icon: "🟨", color: C.yellow },
  red: { label: "Cartão vermelho", icon: "🟥", color: C.red },
};

const MEDALS = ["🥇", "🥈", "🥉"];

// ---------------------------------------------------------------------------
// Estilos globais (keyframes) — injetados uma vez
// ---------------------------------------------------------------------------
function GlobalStyle() {
  return (
    <style>{`
      @keyframes crestPop {
        0% { transform: scale(0.6) rotate(-10deg); opacity: 0; }
        60% { transform: scale(1.08) rotate(3deg); opacity: 1; }
        100% { transform: scale(1) rotate(0deg); opacity: 1; }
      }
      @keyframes floatUp {
        0% { transform: translateY(0) scale(0.5); opacity: 0; }
        15% { opacity: 1; }
        100% { transform: translateY(-70px) scale(1.15); opacity: 0; }
      }
      @keyframes shimmer {
        0% { background-position: 0% 50%; }
        100% { background-position: 200% 50%; }
      }
      @keyframes popIn {
        0% { transform: scale(0.92); opacity: 0; }
        100% { transform: scale(1); opacity: 1; }
      }
      .pelada-pop { animation: popIn 0.25s ease-out; }
      .pelada-shimmer {
        background: linear-gradient(90deg, ${C.goldSoft}, ${C.gold}55, ${C.goldSoft});
        background-size: 200% 100%;
        animation: shimmer 2.2s linear infinite;
      }
    `}</style>
  );
}

function Confetti({ show }) {
  if (!show) return null;
  const bits = ["⚽", "🎉", "⭐", "🎊", "⚽", "🎉"];
  return (
    <div className="pointer-events-none absolute inset-0 overflow-visible" style={{ zIndex: 20 }}>
      {bits.map((b, i) => (
        <span
          key={i}
          style={{
            position: "absolute",
            left: `${10 + i * 15}%`,
            bottom: 0,
            fontSize: 20,
            animation: `floatUp 0.9s ease-out ${i * 0.05}s`,
          }}
        >
          {b}
        </span>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Pequenos componentes
// ---------------------------------------------------------------------------

function Crest({ size = 64 }) {
  const [spin, setSpin] = useState(0);
  return (
    <div
      key={spin}
      onClick={() => setSpin((s) => s + 1)}
      role="button"
      aria-label="Brasão do Clube dos 40"
      className="transition-transform duration-300 hover:scale-110 active:scale-95 cursor-pointer"
      style={{
        width: size,
        height: size,
        borderRadius: "9999px",
        background: `radial-gradient(circle at 35% 28%, ${C.cardAlt}, ${C.bg2} 72%)`,
        border: `3px dashed ${C.gold}`,
        boxShadow: `0 0 0 4px ${C.bg2}, 0 8px 18px #00000055`,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        flexShrink: 0,
        animation: "crestPop 0.6s ease-out",
      }}
    >
      <span style={{ fontSize: size * 0.14, color: C.gold, lineHeight: 1 }}>★</span>
      <span style={{ fontFamily: DISPLAY_FONT, fontWeight: 900, fontSize: size * 0.36, color: C.chalk, lineHeight: 1 }}>
        40
      </span>
    </div>
  );
}

function JerseyBadge({ name, team, size = 32 }) {
  const bg = team === "B" ? C.gold : C.teamA;
  const fg = "#0F2A1D";
  return (
    <div
      title={name}
      style={{
        width: size,
        height: size,
        borderRadius: "9999px",
        background: bg,
        color: fg,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontWeight: 800,
        fontSize: size * 0.38,
        fontFamily: DISPLAY_FONT,
        flexShrink: 0,
        border: `2px solid ${C.chalk}22`,
      }}
    >
      {initials(name)}
    </div>
  );
}

function Footer() {
  return (
    <div className="mt-10 pt-5 flex flex-col items-center gap-1" style={{ borderTop: `1px dashed ${C.line}` }}>
      <span style={{ fontSize: 16 }}>⚽</span>
      <span style={{ fontFamily: CONDENSED_FONT, fontSize: 12, letterSpacing: 1, color: C.chalkDim }}>
        FEITO POR <span style={{ color: C.gold, fontWeight: 700 }}>LEONARDO NAZARIO</span>
      </span>
    </div>
  );
}

function EmptyState({ title, body, emoji = "⚽" }) {
  return (
    <div
      className="flex flex-col items-center justify-center text-center px-6 py-14 rounded-2xl"
      style={{ border: `1px dashed ${C.line}`, color: C.chalkDim }}
    >
      <div style={{ fontSize: 30, marginBottom: 6 }}>{emoji}</div>
      <div style={{ fontFamily: DISPLAY_FONT, letterSpacing: 0.5, fontSize: 19, color: C.chalk }}>{title}</div>
      <div className="mt-2 text-sm max-w-xs">{body}</div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// App
// ---------------------------------------------------------------------------

export default function PeladaApp() {
  const [data, setData] = useState({ players: [], matches: [] });
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState("");
  const [tab, setTab] = useState("partidas");
  const [openMatchId, setOpenMatchId] = useState(null);
  const [showNewMatch, setShowNewMatch] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("clube-dos-40-data");
      if (raw) {
        const parsed = JSON.parse(raw);
        setData({ players: parsed.players || [], matches: parsed.matches || [] });
      }
    } catch (e) {
      // dado corrompido ou ainda não existe — segue com estado vazio
    } finally {
      setLoaded(true);
    }
  }, []);

  function persist(next) {
    setData(next);
    try {
      localStorage.setItem("clube-dos-40-data", JSON.stringify(next));
      setError("");
    } catch (e) {
      setError("Não consegui salvar agora. Verifique o espaço de armazenamento do navegador.");
    }
  }

  function addPlayer(name) {
    const trimmed = name.trim();
    if (!trimmed) return;
    if (data.players.some((p) => p.name.toLowerCase() === trimmed.toLowerCase())) return;
    persist({ ...data, players: [...data.players, { id: uid(), name: trimmed }] });
  }

  function removePlayer(id) {
    const inUse = data.matches.some(
      (m) => m.teamA.playerIds.includes(id) || m.teamB.playerIds.includes(id)
    );
    if (inUse) {
      setError("Esse jogador já tem partidas registradas e não pode ser removido.");
      return;
    }
    persist({ ...data, players: data.players.filter((p) => p.id !== id) });
  }

  function createMatch({ date, teamAName, teamAIds, teamBName, teamBIds }) {
    const match = {
      id: uid(),
      date,
      teamA: { name: teamAName || "Time A", playerIds: teamAIds },
      teamB: { name: teamBName || "Time B", playerIds: teamBIds },
      events: [],
    };
    persist({ ...data, matches: [match, ...data.matches] });
    setShowNewMatch(false);
    setOpenMatchId(match.id);
  }

  function deleteMatch(id) {
    persist({ ...data, matches: data.matches.filter((m) => m.id !== id) });
    setOpenMatchId(null);
  }

  function addEvent(matchId, team, playerId, type) {
    if (!playerId) return;
    persist({
      ...data,
      matches: data.matches.map((m) =>
        m.id === matchId ? { ...m, events: [...m.events, { id: uid(), team, playerId, type }] } : m
      ),
    });
  }

  function removeEvent(matchId, eventId) {
    persist({
      ...data,
      matches: data.matches.map((m) =>
        m.id === matchId ? { ...m, events: m.events.filter((e) => e.id !== eventId) } : m
      ),
    });
  }

  function updateTeamPlayers(matchId, side, ids) {
    persist({
      ...data,
      matches: data.matches.map((m) => {
        if (m.id !== matchId) return m;
        return {
          ...m,
          teamA: side === "A" ? { ...m.teamA, playerIds: ids } : m.teamA,
          teamB: side === "B" ? { ...m.teamB, playerIds: ids } : m.teamB,
        };
      }),
    });
  }

  const playerName = (id) => data.players.find((p) => p.id === id)?.name || "Jogador removido";

  function scoreOf(match) {
    const a = match.events.filter((e) => e.type === "goal" && e.team === "A").length;
    const b = match.events.filter((e) => e.type === "goal" && e.team === "B").length;
    return { a, b };
  }

  function winnerOf(match) {
    const { a, b } = scoreOf(match);
    if (a === b) return "draw";
    return a > b ? "A" : "B";
  }

  const rankings = useMemo(() => {
    const goals = {};
    const assists = {};
    const wins = {};
    const games = {};

    for (const m of data.matches) {
      for (const id of m.teamA.playerIds) games[id] = (games[id] || 0) + 1;
      for (const id of m.teamB.playerIds) games[id] = (games[id] || 0) + 1;

      for (const ev of m.events) {
        if (ev.type === "goal") goals[ev.playerId] = (goals[ev.playerId] || 0) + 1;
        if (ev.type === "assist") assists[ev.playerId] = (assists[ev.playerId] || 0) + 1;
      }

      const w = winnerOf(m);
      if (w !== "draw") {
        const ids = w === "A" ? m.teamA.playerIds : m.teamB.playerIds;
        for (const id of ids) wins[id] = (wins[id] || 0) + 1;
      }
    }

    const toSorted = (obj) =>
      Object.entries(obj)
        .map(([id, count]) => ({ id, count, games: games[id] || 0 }))
        .sort((x, y) => y.count - x.count)
        .slice(0, 10);

    return { goals: toSorted(goals), assists: toSorted(assists), wins: toSorted(wins) };
  }, [data.matches]);

  const openMatch = data.matches.find((m) => m.id === openMatchId);

  if (!loaded) {
    return (
      <div
        className="min-h-screen flex items-center justify-center gap-2"
        style={{ background: C.bg, color: C.chalk, fontFamily: DISPLAY_FONT }}
      >
        Carregando…
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full" style={{ background: C.bg, color: C.chalk }}>
      <GlobalStyle />
      <div className="max-w-2xl mx-auto px-4 pb-24">
        {/* Header */}
        <div className="pt-8 pb-5 flex items-center gap-4">
          <Crest size={64} />
          <div>
            <div style={{ fontFamily: DISPLAY_FONT, letterSpacing: 1, fontSize: 30, fontWeight: 900, lineHeight: 1.05 }}>
              CLUBE DOS 40
            </div>
          </div>
        </div>

        {error && (
          <div
            className="mb-4 px-3 py-2 rounded-lg text-sm pelada-pop"
            style={{ background: "#D6454522", border: `1px solid ${C.red}`, color: C.chalk }}
          >
            {error}
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-1 mb-5 rounded-xl p-1" style={{ background: C.bg2 }}>
          {[
            { id: "partidas", label: "Partidas", icon: Calendar },
            { id: "jogadores", label: "Elenco", icon: Users },
            { id: "ranking", label: "Ranking", icon: Trophy },
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => {
                setTab(id);
                setOpenMatchId(null);
              }}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-sm font-semibold transition-all duration-200"
              style={{
                background: tab === id ? C.gold : "transparent",
                color: tab === id ? "#1B2A20" : C.chalkDim,
                transform: tab === id ? "scale(1.02)" : "scale(1)",
              }}
            >
              <Icon size={15} />
              {label}
            </button>
          ))}
        </div>

        {tab === "partidas" && !openMatch && (
          <MatchesTab matches={data.matches} scoreOf={scoreOf} onOpen={setOpenMatchId} onNew={() => setShowNewMatch(true)} />
        )}

        {tab === "partidas" && openMatch && (
          <MatchDetail
            match={openMatch}
            players={data.players}
            playerName={playerName}
            scoreOf={scoreOf}
            onBack={() => setOpenMatchId(null)}
            onAddEvent={(team, playerId, type) => addEvent(openMatch.id, team, playerId, type)}
            onRemoveEvent={(eventId) => removeEvent(openMatch.id, eventId)}
            onDeleteMatch={() => deleteMatch(openMatch.id)}
            onUpdateTeam={(side, ids) => updateTeamPlayers(openMatch.id, side, ids)}
          />
        )}

        {tab === "jogadores" && <PlayersTab players={data.players} onAdd={addPlayer} onRemove={removePlayer} />}

        {tab === "ranking" && <RankingsTab rankings={rankings} playerName={playerName} />}

        <Footer />
      </div>

      {showNewMatch && (
        <NewMatchModal players={data.players} onAddPlayer={addPlayer} onClose={() => setShowNewMatch(false)} onCreate={createMatch} />
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Partidas — lista
// ---------------------------------------------------------------------------

function MatchesTab({ matches, scoreOf, onOpen, onNew }) {
  return (
    <div>
      <button
        onClick={onNew}
        className="w-full flex items-center justify-center gap-2 py-3 rounded-xl mb-5 font-bold transition-transform duration-150 hover:scale-105 active:scale-95"
        style={{ background: C.gold, color: "#1B2A20", fontFamily: DISPLAY_FONT, letterSpacing: 0.5, boxShadow: `0 6px 16px #00000040` }}
      >
        <Plus size={18} /> NOVA PARTIDA
      </button>

      {matches.length === 0 ? (
        <EmptyState
          emoji="🥅"
          title="Nenhuma partida ainda"
          body="Registre o placar depois do jogo para começar o histórico do clube."
        />
      ) : (
        <div className="flex flex-col gap-3">
          {matches.map((m) => {
            const { a, b } = scoreOf(m);
            return (
              <button
                key={m.id}
                onClick={() => onOpen(m.id)}
                className="text-left rounded-2xl p-4 transition-all duration-200 hover:scale-105 hover:brightness-110 active:scale-95"
                style={{ background: C.card, border: `1px solid ${C.line}`, boxShadow: "0 4px 10px #00000022" }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span style={{ color: C.chalkDim, fontSize: 12 }}>{formatDate(m.date)}</span>
                  <ChevronRight size={16} color={C.chalkDim} />
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-semibold truncate pr-2" style={{ maxWidth: "40%" }}>{m.teamA.name}</span>
                  <span style={{ fontFamily: MONO_FONT, fontSize: 22, fontWeight: 700, color: C.gold }}>{a} – {b}</span>
                  <span className="font-semibold truncate pl-2 text-right" style={{ maxWidth: "40%" }}>{m.teamB.name}</span>
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Detalhe da partida
// ---------------------------------------------------------------------------

function MatchDetail({ match, players, playerName, scoreOf, onBack, onAddEvent, onRemoveEvent, onDeleteMatch, onUpdateTeam }) {
  const { a, b } = scoreOf(match);
  const [team, setTeam] = useState("A");
  const [player, setPlayer] = useState("");
  const [type, setType] = useState("goal");
  const [celebrate, setCelebrate] = useState(false);
  const [editingSide, setEditingSide] = useState(null); // null | "A" | "B"
  const [draftIds, setDraftIds] = useState([]);

  const lineup = team === "A" ? match.teamA.playerIds : match.teamB.playerIds;

  function startEdit(side) {
    setDraftIds(side === "A" ? [...match.teamA.playerIds] : [...match.teamB.playerIds]);
    setEditingSide(side);
  }

  function toggleDraft(id) {
    setDraftIds((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]));
  }

  function saveEdit() {
    onUpdateTeam(editingSide, draftIds);
    setEditingSide(null);
  }

  function submit() {
    if (!player) return;
    onAddEvent(team, player, type);
    if (type === "goal") {
      setCelebrate(true);
      setTimeout(() => setCelebrate(false), 900);
    }
    setPlayer("");
  }

  return (
    <div>
      <button onClick={onBack} className="flex items-center gap-1 mb-4 text-sm" style={{ color: C.chalkDim }}>
        <ArrowLeft size={15} /> Voltar
      </button>

      <div className="rounded-2xl p-5 mb-4 pelada-pop" style={{ background: C.card, border: `1px solid ${C.line}` }}>
        <div style={{ color: C.chalkDim, fontSize: 12, marginBottom: 8 }}>{formatDate(match.date)}</div>
        <div className="flex items-center justify-between">
          <div className="font-bold text-lg" style={{ maxWidth: "35%" }}>{match.teamA.name}</div>
          <div style={{ fontFamily: MONO_FONT, fontSize: 34, fontWeight: 800, color: C.gold }}>{a} – {b}</div>
          <div className="font-bold text-lg text-right" style={{ maxWidth: "35%" }}>{match.teamB.name}</div>
        </div>
      </div>

      {/* Escalações */}
      <div className="grid grid-cols-2 gap-3 mb-5">
        {[{ label: match.teamA.name, ids: match.teamA.playerIds, t: "A" }, { label: match.teamB.name, ids: match.teamB.playerIds, t: "B" }].map((side) => (
          <div key={side.t} className="rounded-2xl p-3" style={{ background: C.bg2, border: `1px solid ${C.line}` }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold truncate" style={{ color: C.chalkDim }}>{side.label}</span>
              <button
                onClick={() => startEdit(side.t)}
                className="text-xs font-semibold transition-transform duration-150 hover:scale-105 active:scale-95"
                style={{ color: C.gold }}
              >
                Editar
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {side.ids.map((id) => (
                <JerseyBadge key={id} name={playerName(id)} team={side.t} size={28} />
              ))}
            </div>
          </div>
        ))}
      </div>

      {editingSide && (
        <div className="rounded-2xl p-4 mb-5 pelada-pop" style={{ background: C.cardAlt, border: `1px solid ${C.line}` }}>
          <div className="flex items-center justify-between mb-3">
            <div style={{ fontFamily: DISPLAY_FONT, letterSpacing: 0.5, fontSize: 15 }}>
              ESCALAÇÃO · {editingSide === "A" ? match.teamA.name : match.teamB.name}
            </div>
            <span style={{ color: C.chalkDim, fontSize: 11 }}>{draftIds.length}/11 escalados</span>
          </div>
          <div className="flex flex-col gap-1 max-h-64 overflow-y-auto pr-1 mb-3">
            {players.map((p) => {
              const otherIds = editingSide === "A" ? match.teamB.playerIds : match.teamA.playerIds;
              const blocked = otherIds.includes(p.id);
              return (
                <label
                  key={p.id}
                  className="flex items-center gap-2 text-sm rounded-lg px-2 py-1.5 transition-colors duration-150"
                  style={{
                    background: draftIds.includes(p.id) ? (editingSide === "A" ? `${C.teamA}33` : `${C.gold}33`) : "transparent",
                    opacity: blocked ? 0.3 : 1,
                  }}
                >
                  <input type="checkbox" checked={draftIds.includes(p.id)} disabled={blocked} onChange={() => toggleDraft(p.id)} />
                  {p.name}
                  {blocked && <span style={{ color: C.chalkDim, fontSize: 11 }}>· no outro time</span>}
                </label>
              );
            })}
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setEditingSide(null)}
              className="flex-1 py-2 rounded-lg text-sm font-semibold"
              style={{ background: C.bg2, color: C.chalkDim }}
            >
              Cancelar
            </button>
            <button
              onClick={saveEdit}
              className="flex-1 py-2 rounded-lg text-sm font-bold transition-transform duration-150 hover:scale-105 active:scale-95"
              style={{ background: C.coral, color: "#1B1208" }}
            >
              Salvar escalação
            </button>
          </div>
        </div>
      )}

      {/* Adicionar evento */}
      <div className="relative rounded-2xl p-4 mb-5" style={{ background: C.cardAlt, border: `1px solid ${C.line}` }}>
        <Confetti show={celebrate} />
        <div style={{ fontFamily: DISPLAY_FONT, letterSpacing: 0.5, fontSize: 15, marginBottom: 10 }}>
          REGISTRAR LANCE
        </div>
        <div className="flex gap-2 mb-2">
          {["A", "B"].map((t) => (
            <button
              key={t}
              onClick={() => { setTeam(t); setPlayer(""); }}
              className="flex-1 py-1.5 rounded-lg text-sm font-semibold transition-colors duration-150"
              style={{ background: team === t ? (t === "A" ? C.teamA : C.gold) : C.bg2, color: team === t ? "#1B2A20" : C.chalkDim }}
            >
              {t === "A" ? match.teamA.name : match.teamB.name}
            </button>
          ))}
        </div>

        <select
          value={player}
          onChange={(e) => setPlayer(e.target.value)}
          className="w-full mb-2 rounded-lg px-3 py-2 text-sm"
          style={{ background: C.bg2, color: C.chalk, border: `1px solid ${C.line}` }}
        >
          <option value="">Selecione o jogador…</option>
          {lineup.map((id) => (
            <option key={id} value={id}>{playerName(id)}</option>
          ))}
        </select>

        <div className="flex gap-2 mb-3">
          {Object.entries(EVENT_META).map(([key, meta]) => (
            <button
              key={key}
              onClick={() => setType(key)}
              className="flex-1 py-1.5 rounded-lg text-lg flex items-center justify-center transition-transform duration-150"
              style={{ background: type === key ? C.gold : C.bg2, transform: type === key ? "scale(1.08)" : "scale(1)" }}
            >
              <span>{meta.icon}</span>
            </button>
          ))}
        </div>

        <button
          onClick={submit}
          disabled={!player}
          className="w-full py-2 rounded-lg font-bold text-sm transition-transform duration-150 hover:scale-105 active:scale-95"
          style={{ background: player ? C.coral : C.line, color: player ? "#1B1208" : C.chalkDim, opacity: player ? 1 : 0.6 }}
        >
          {type === "goal" ? "Registrar gol" : "Adicionar"}
        </button>
      </div>

      {/* Linha do tempo */}
      <div className="mb-6">
        <div style={{ fontFamily: DISPLAY_FONT, letterSpacing: 0.5, fontSize: 15, marginBottom: 10 }}>
          LANCES DA PARTIDA
        </div>
        {match.events.length === 0 ? (
          <EmptyState emoji="🔇" title="Nenhum lance registrado" body="Adicione gols, assistências e cartões acima." />
        ) : (
          <div className="flex flex-col gap-2">
            {match.events.map((ev) => {
              const meta = EVENT_META[ev.type];
              return (
                <div key={ev.id} className="flex items-center justify-between rounded-xl px-3 py-2 pelada-pop" style={{ background: C.card, border: `1px solid ${C.line}` }}>
                  <div className="flex items-center gap-2">
                    <span>{meta.icon}</span>
                    <JerseyBadge name={playerName(ev.playerId)} team={ev.team} size={24} />
                    <span className="text-sm">{playerName(ev.playerId)}</span>
                    <span style={{ color: C.chalkDim, fontSize: 12 }}>· {meta.label}</span>
                  </div>
                  <button onClick={() => onRemoveEvent(ev.id)}>
                    <X size={15} color={C.chalkDim} />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <button
        onClick={() => { if (window.confirm("Excluir esta partida? Essa ação não pode ser desfeita.")) onDeleteMatch(); }}
        className="flex items-center gap-1.5 text-sm mx-auto"
        style={{ color: C.red }}
      >
        <Trash2 size={14} /> Excluir partida
      </button>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Nova partida
// ---------------------------------------------------------------------------

function NewMatchModal({ players, onAddPlayer, onClose, onCreate }) {
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [teamAName, setTeamAName] = useState("Time A");
  const [teamBName, setTeamBName] = useState("Time B");
  const [teamAIds, setTeamAIds] = useState([]);
  const [teamBIds, setTeamBIds] = useState([]);
  const [newName, setNewName] = useState("");

  function toggle(side, id) {
    if (side === "A") {
      setTeamAIds((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]));
      setTeamBIds((cur) => cur.filter((x) => x !== id));
    } else {
      setTeamBIds((cur) => (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]));
      setTeamAIds((cur) => cur.filter((x) => x !== id));
    }
  }

  function addNewPlayer() {
    if (!newName.trim()) return;
    onAddPlayer(newName.trim());
    setNewName("");
  }

  function submit() {
    if (teamAIds.length === 0 || teamBIds.length === 0) return;
    onCreate({ date, teamAName, teamAIds, teamBName, teamBIds });
  }

  return (
    <div className="fixed inset-0 flex items-end sm:items-center justify-center z-50" style={{ background: "#00000088" }}>
      <div className="w-full sm:max-w-lg max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl p-5 pelada-pop" style={{ background: C.bg, border: `1px solid ${C.line}` }}>
        <div className="flex items-center justify-between mb-4">
          <div style={{ fontFamily: DISPLAY_FONT, letterSpacing: 0.5, fontSize: 20 }}>NOVA PARTIDA</div>
          <button onClick={onClose}><X size={20} color={C.chalkDim} /></button>
        </div>

        <label className="text-xs" style={{ color: C.chalkDim }}>Data</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="w-full mb-4 mt-1 rounded-lg px-3 py-2"
          style={{ background: C.card, color: C.chalk, border: `1px solid ${C.line}` }}
        />

        <label className="text-xs" style={{ color: C.chalkDim }}>Novo jogador</label>
        <div className="flex gap-2 mb-4 mt-1">
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addNewPlayer()}
            placeholder="Nome do jogador"
            className="flex-1 rounded-lg px-3 py-2"
            style={{ background: C.card, color: C.chalk, border: `1px solid ${C.line}` }}
          />
          <button onClick={addNewPlayer} className="px-3 rounded-lg transition-transform duration-150 hover:scale-105 active:scale-95" style={{ background: C.gold, color: "#1B2A20" }}>
            <Plus size={16} />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {[{ side: "A", name: teamAName, setName: setTeamAName, ids: teamAIds, other: teamBIds },
            { side: "B", name: teamBName, setName: setTeamBName, ids: teamBIds, other: teamAIds }].map((col) => (
            <div key={col.side}>
              <input
                value={col.name}
                onChange={(e) => col.setName(e.target.value)}
                className="w-full mb-2 rounded-lg px-2 py-1.5 text-sm font-semibold"
                style={{ background: C.card, color: C.chalk, border: `1px solid ${C.line}` }}
              />
              <div style={{ color: C.chalkDim, fontSize: 11, marginBottom: 6 }}>{col.ids.length}/11 escalados</div>
              <div className="flex flex-col gap-1 max-h-64 overflow-y-auto pr-1">
                {players.map((p) => (
                  <label
                    key={p.id}
                    className="flex items-center gap-2 text-sm rounded-lg px-2 py-1.5 transition-colors duration-150"
                    style={{
                      background: col.ids.includes(p.id) ? (col.side === "A" ? `${C.teamA}33` : `${C.gold}33`) : "transparent",
                      opacity: col.other.includes(p.id) ? 0.3 : 1,
                    }}
                  >
                    <input type="checkbox" checked={col.ids.includes(p.id)} disabled={col.other.includes(p.id)} onChange={() => toggle(col.side, p.id)} />
                    {p.name}
                  </label>
                ))}
                {players.length === 0 && <div style={{ color: C.chalkDim, fontSize: 12 }}>Cadastre jogadores acima.</div>}
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={submit}
          disabled={teamAIds.length === 0 || teamBIds.length === 0}
          className="w-full mt-5 py-3 rounded-xl font-bold transition-transform duration-150 hover:scale-105 active:scale-95"
          style={{
            background: teamAIds.length && teamBIds.length ? C.coral : C.line,
            color: teamAIds.length && teamBIds.length ? "#1B1208" : C.chalkDim,
            fontFamily: DISPLAY_FONT,
            letterSpacing: 0.5,
          }}
        >
          Criar partida
        </button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Elenco
// ---------------------------------------------------------------------------

function PlayersTab({ players, onAdd, onRemove }) {
  const [name, setName] = useState("");
  const [query, setQuery] = useState("");

  function submit() {
    onAdd(name);
    setName("");
  }

  const filtered = players.filter((p) => p.name.toLowerCase().includes(query.toLowerCase()));

  return (
    <div>
      <div className="flex gap-2 mb-4">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder="Nome do jogador"
          className="flex-1 rounded-lg px-3 py-2"
          style={{ background: C.card, color: C.chalk, border: `1px solid ${C.line}` }}
        />
        <button onClick={submit} className="px-4 rounded-lg font-bold transition-transform duration-150 hover:scale-105 active:scale-95" style={{ background: C.gold, color: "#1B2A20" }}>
          <Plus size={16} />
        </button>
      </div>

      {players.length > 5 && (
        <div className="relative mb-3">
          <Search size={14} style={{ position: "absolute", left: 10, top: 10 }} color={C.chalkDim} />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar jogador…"
            className="w-full rounded-lg pl-8 pr-3 py-2 text-sm"
            style={{ background: C.bg2, color: C.chalk, border: `1px solid ${C.line}` }}
          />
        </div>
      )}

      {players.length === 0 ? (
        <EmptyState emoji="🫥" title="Nenhum jogador" body="Adicione os jogadores do grupo." />
      ) : (
        <div className="flex flex-col gap-2">
          {filtered.map((p) => (
            <div key={p.id} className="flex items-center justify-between rounded-xl px-3 py-2 transition-transform duration-150 hover:scale-105 active:scale-95" style={{ background: C.card, border: `1px solid ${C.line}` }}>
              <div className="flex items-center gap-2">
                <JerseyBadge name={p.name} team="A" size={28} />
                <span>{p.name}</span>
              </div>
              <button onClick={() => onRemove(p.id)}>
                <Trash2 size={15} color={C.chalkDim} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Ranking
// ---------------------------------------------------------------------------

function RankingBlock({ title, emoji, rows, playerName, unit }) {
  return (
    <div className="rounded-2xl p-4 mb-4 pelada-pop" style={{ background: C.card, border: `1px solid ${C.line}` }}>
      <div className="flex items-center gap-2 mb-3">
        <span style={{ fontSize: 17 }}>{emoji}</span>
        <span style={{ fontFamily: DISPLAY_FONT, letterSpacing: 0.5, fontSize: 15 }}>{title}</span>
      </div>
      {rows.length === 0 ? (
        <div style={{ color: C.chalkDim, fontSize: 13 }}>Sem dados ainda.</div>
      ) : (
        <div className="flex flex-col gap-1.5">
          {rows.map((r, i) => (
            <div
              key={r.id}
              className={`flex items-center justify-between rounded-lg px-2 py-1.5 ${i === 0 ? "pelada-shimmer" : ""}`}
            >
              <div className="flex items-center gap-2">
                <span style={{ width: 22, textAlign: "center", fontSize: i < 3 ? 16 : 13, fontFamily: MONO_FONT, color: C.chalkDim }}>
                  {i < 3 ? MEDALS[i] : i + 1}
                </span>
                <JerseyBadge name={playerName(r.id)} team={i === 0 ? "B" : "A"} size={24} />
                <span className="text-sm">{playerName(r.id)}</span>
              </div>
              <span style={{ fontFamily: MONO_FONT, fontWeight: 700, color: C.gold }}>{r.count} {unit}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function RankingsTab({ rankings, playerName }) {
  return (
    <div>
      <RankingBlock title="ARTILHARIA" emoji="🏆" rows={rankings.goals} playerName={playerName} unit="gols" />
      <RankingBlock title="ASSISTÊNCIAS" emoji="🎯" rows={rankings.assists} playerName={playerName} unit="assist." />
      <RankingBlock title="MAIS VITÓRIAS" emoji="🔥" rows={rankings.wins} playerName={playerName} unit="vit." />
    </div>
  );
}
