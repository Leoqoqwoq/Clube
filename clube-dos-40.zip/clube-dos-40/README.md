# Clube dos 40 ⚽

App da pelada: partidas, times, gols, assistências, cartões e ranking.
Feito por Leonardo Nazário.

Os dados ficam salvos no armazenamento do próprio navegador (`localStorage`),
ou seja: cada aparelho/navegador guarda os seus dados. Se limpar o cache do
navegador, os dados somem — vale fazer backup de vez em quando (dá pra copiar
o conteúdo salvo pelas ferramentas de desenvolvedor, se precisar).

## Rodar no seu computador

Precisa ter o [Node.js](https://nodejs.org) instalado (versão 18 ou mais nova).

```bash
npm install
npm run dev
```

Abre em `http://localhost:5173`.

## Subir pro GitHub

Se ainda não tem um repositório:

1. Cria um repositório novo em https://github.com/new (pode chamar de `clube-dos-40`, público)
2. Não marca nenhuma opção de "adicionar README" — deixa vazio
3. Copia a URL do repositório (algo como `https://github.com/SEU-USUARIO/clube-dos-40.git`)

Depois, no terminal, dentro dessa pasta do projeto:

```bash
git init
git add .
git commit -m "Primeira versão do Clube dos 40"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/clube-dos-40.git
git push -u origin main
```

## Publicar de graça (GitHub Pages)

O projeto já vem com o pacote `gh-pages` configurado. Depois de já ter feito
o passo acima (repositório criado e código enviado):

```bash
npm run deploy
```

Isso builda o app e sobe o resultado pra uma branch chamada `gh-pages`.

Depois:

1. Vai em **Settings → Pages** no seu repositório no GitHub
2. Em "Build and deployment", escolhe **Deploy from a branch**
3. Seleciona a branch **gh-pages** e a pasta **/ (root)**
4. Salva

Em alguns minutos o site fica no ar em:

```
https://SEU-USUARIO.github.io/clube-dos-40/
```

## Atualizando depois

Sempre que quiser mandar uma mudança nova:

```bash
git add .
git commit -m "descrição do que mudou"
git push
npm run deploy
```

## Se quiser dados compartilhados entre a galera

Como está, cada pessoa que acessa o site vê só os próprios dados (salvos no
navegador dela). Se no futuro quiser que todo mundo da pelada veja as mesmas
partidas e ranking, dá pra trocar o `localStorage` por um banco de dados
gratuito como o [Supabase](https://supabase.com) — é um passo a mais, mas
mantém tudo de graça e compartilhado.
